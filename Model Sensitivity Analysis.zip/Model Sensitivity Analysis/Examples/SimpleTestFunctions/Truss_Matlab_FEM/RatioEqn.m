function f = RatioEqn(r,d0,L,N)
  
  f = d0*r^N - L*r +L-d0;
  
  
