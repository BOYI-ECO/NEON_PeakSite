function Y = uq_Rh(x)      % x represent para space, matrix size [n,30] 
sample_num = size(x,1);    % sampling size

Y = zeros(sample_num,1);   % Generate a empty output file

for i=1:sample_num         
    para = x(i,:);         % get one set of parameter
    save ('..\SimpleTestFunctions\para.txt','para','-ASCII');
    
    system('python ..\SimpleTestFunctions\MainFunction_Isotope_Marsden.py');
    
    %Rpath = 'C:\Program Files\R\R-3.6.1\bin';
    %RscriptFileName = 'C:\Users\boyi\Desktop\R_file_test\CModel.R'; 
    %RunRcode(RscriptFileName, Rpath);     % file saved into the runing .m folder 
    
    Rh = importdata('..\SimpleTestFunctions\Rh_sum.txt');
    Y(i) = Rh(550);
end
end