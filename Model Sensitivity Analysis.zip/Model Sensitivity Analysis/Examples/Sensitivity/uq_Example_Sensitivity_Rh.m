%% SENSITIVITY: BOREHOLE MODEL
%
% This example showcases the application of different sensitivity analysis
% techniques available in UQLab to the 
% <https://uqworld.org/t/borehole-function/ borehole function>.

%% 1 - INITIALIZE UQLAB
%
% Clear all variables from the workspace, set the random number generator
% for reproducible results, and initialize the UQLab framework:
clearvars
rng(100,'twister')
uqlab

%% 2 - COMPUTATIONAL MODEL
%
% The computational model is an $23$-dimensional analytical formula 
% that is used to model the water flow through a borehole.
% The borehole function |uq_borehole| is supplied with UQLab.
%
% Create a MODEL object from the function file:
ModelOpts.mFile = 'uq_Rh';

myModel = uq_createModel(ModelOpts);

%% 3 - PROBABILISTIC INPUT MODEL
% The probabilistic input model consists of 30 independent random variables.
% Specify the marginals as follows:
InputOpts.Marginals(1).Name = 'CN_AOM1';
InputOpts.Marginals(1).Type = 'Uniform';
InputOpts.Marginals(1).Parameters = [15.0 35.0];

InputOpts.Marginals(2).Name = 'CN_AOM2';
InputOpts.Marginals(2).Type = 'Uniform';
InputOpts.Marginals(2).Parameters = [100.0 180.0];

InputOpts.Marginals(3).Name = 'CN_AOM3';
InputOpts.Marginals(3).Type = 'Uniform';
InputOpts.Marginals(3).Parameters = [100.0 400.0];

InputOpts.Marginals(4).Name = 'CN_SMB1';
InputOpts.Marginals(4).Type = 'Uniform';
InputOpts.Marginals(4).Parameters = [5.0 25.0];

InputOpts.Marginals(5).Name = 'CN_SMB2';
InputOpts.Marginals(5).Type = 'Uniform';
InputOpts.Marginals(5).Parameters = [5.0 25.0];

InputOpts.Marginals(6).Name = 'CN_SMR';
InputOpts.Marginals(6).Type = 'Uniform';
InputOpts.Marginals(6).Parameters = [5.0 15.0];

InputOpts.Marginals(7).Name = 'CN_NOM';
InputOpts.Marginals(7).Type = 'Uniform';
InputOpts.Marginals(7).Parameters = [5.0 25.0];

InputOpts.Marginals(8).Name = 'CN_MOM';
InputOpts.Marginals(8).Type = 'Uniform';
InputOpts.Marginals(8).Parameters = [5.0 25.0];

InputOpts.Marginals(9).Name = 'kbase_litter';
InputOpts.Marginals(9).Type = 'Uniform';
InputOpts.Marginals(9).Parameters = [0.001 5.0];

InputOpts.Marginals(10).Name = 'kmax_AOM1';
InputOpts.Marginals(10).Type = 'Uniform';
InputOpts.Marginals(10).Parameters = [0.001 2.0];

InputOpts.Marginals(11).Name = 'kmax_AOM2';
InputOpts.Marginals(11).Type = 'Uniform';
InputOpts.Marginals(11).Parameters = [0.01 5.0];

InputOpts.Marginals(12).Name = 'kmax_AOM3';
InputOpts.Marginals(12).Type = 'Uniform';
InputOpts.Marginals(12).Parameters = [0.1 40.0];

InputOpts.Marginals(13).Name = 'kmax_SMR';
InputOpts.Marginals(13).Type = 'Uniform';
InputOpts.Marginals(13).Parameters = [0.001 0.10];

InputOpts.Marginals(14).Name = 'kmax_NOM';
InputOpts.Marginals(14).Type = 'Uniform';
InputOpts.Marginals(14).Parameters = [0.001 1];

InputOpts.Marginals(15).Name = 'kmax_MOM';
InputOpts.Marginals(15).Type = 'Uniform';
InputOpts.Marginals(15).Parameters = [0.1 100.0];

InputOpts.Marginals(16).Name = 'fAOM1_SMB1';
InputOpts.Marginals(16).Type = 'Uniform';
InputOpts.Marginals(16).Parameters = [0.10 0.90];

InputOpts.Marginals(17).Name = 'fAOM2_SMB1';
InputOpts.Marginals(17).Type = 'Uniform';
InputOpts.Marginals(17).Parameters = [0.10 0.90];

InputOpts.Marginals(18).Name = 'fAOM_MOM';
InputOpts.Marginals(18).Type = 'Uniform';
InputOpts.Marginals(18).Parameters = [0.10 0.25];

InputOpts.Marginals(19).Name = 'fAOM3_SMB1';
InputOpts.Marginals(19).Type = 'Uniform';
InputOpts.Marginals(19).Parameters = [0.10 0.90];

InputOpts.Marginals(20).Name = 'fNOM_SMB1';
InputOpts.Marginals(20).Type = 'Uniform';
InputOpts.Marginals(20).Parameters = [0.1 0.90];

InputOpts.Marginals(21).Name = 'fNOM_MOM';
InputOpts.Marginals(21).Type = 'Uniform';
InputOpts.Marginals(21).Parameters = [0.01 0.35];

InputOpts.Marginals(22).Name = 'fMOM_SMB1';
InputOpts.Marginals(22).Type = 'Uniform';
InputOpts.Marginals(22).Parameters = [0.1 0.90];

InputOpts.Marginals(23).Name = 'fE_AOM1';
InputOpts.Marginals(23).Type = 'Uniform';
InputOpts.Marginals(23).Parameters = [0.10 0.90];

InputOpts.Marginals(24).Name = 'fE_AOM2';
InputOpts.Marginals(24).Type = 'Uniform';
InputOpts.Marginals(24).Parameters = [0.10 0.90];

InputOpts.Marginals(25).Name = 'fE_AOM3';
InputOpts.Marginals(25).Type = 'Uniform';
InputOpts.Marginals(25).Parameters = [0.01 0.15];

InputOpts.Marginals(26).Name = 'fE_NOM';
InputOpts.Marginals(26).Type = 'Uniform';
InputOpts.Marginals(26).Parameters = [0.10 0.90];

InputOpts.Marginals(27).Name = 'fE_MOM';
InputOpts.Marginals(27).Type = 'Uniform';
InputOpts.Marginals(27).Parameters = [0.10 0.90];

InputOpts.Marginals(28).Name = 'fA_SMB1';
InputOpts.Marginals(28).Type = 'Uniform';
InputOpts.Marginals(28).Parameters = [0.1 0.90];

InputOpts.Marginals(29).Name = 'fM_SMB1';
InputOpts.Marginals(29).Type = 'Uniform';
InputOpts.Marginals(29).Parameters = [0.1 0.9];

InputOpts.Marginals(30).Name = 'fA_SMB2';
InputOpts.Marginals(30).Type = 'Uniform';
InputOpts.Marginals(30).Parameters = [0.1 0.9];

InputOpts.Marginals(31).Name = 'fM_SMB2';
InputOpts.Marginals(31).Type = 'Uniform';
InputOpts.Marginals(31).Parameters = [0.1 0.9];

InputOpts.Marginals(32).Name = 'lig_p1';
InputOpts.Marginals(32).Type = 'Uniform';
InputOpts.Marginals(32).Parameters = [4 40];

InputOpts.Marginals(33).Name = 'lig_p2';
InputOpts.Marginals(33).Type = 'Uniform';
InputOpts.Marginals(33).Parameters = [0.9 0.99];

%% Create an INPUT object based on the specified marginals:
myInput = uq_createInput(InputOpts);

%% 4 - SENSITIVITY ANALYSIS
% Sensitivity analysis on the borehole model is performed
% with the following methods:
% * Input/output correlation
% * Standard Regression Coefficients
% * Perturbation method
% * Cotter sensitivity indices
% * Morris elementary effects
% * Sobol' sensitivity indices
% * Borgonovo sensitivity indices
%% 4.1 Input/output correlation analysis
% Select the sensitivity tool and the correlation method:
% CorrSensOpts.Type = 'Sensitivity';
% CorrSensOpts.Method = 'Correlation';

% Specify the sample size used to calculate the correlation-based indices:
% CorrSensOpts.Correlation.SampleSize = 1e4;

% Run the sensitivity analysis:
% CorrAnalysis = uq_createAnalysis(CorrSensOpts);

% Print the results of the analysis:
% uq_print(CorrAnalysis)

% Display a graphical representation of the results:
% uq_display(CorrAnalysis)

%% 4.2 Standard Regression Coefficients (SRC)
% Select the sensitivity tool and the SRC method:
% SRCSensOpts.Type = 'Sensitivity';
% SRCSensOpts.Method = 'SRC';

% Specify the sample size used to calculate the regression-based indices:
% SRCSensOpts.SRC.SampleSize = 1e4;

% Run the sensitivity analysis:
% SRCAnalysis = uq_createAnalysis(SRCSensOpts);

% Print the results of the analysis:
% uq_print(SRCAnalysis)

% Display a graphical representation of the results:
% uq_display(SRCAnalysis)

%% 4.3 Perturbation-based indices 
% Select the sensitivity tool and the perturbation method:
% PerturbationSensOpts.Type = 'Sensitivity';
% PerturbationSensOpts.Method = 'Perturbation';

% Run the sensitivity analysis:
% PerturbationAnalysis = uq_createAnalysis(PerturbationSensOpts);

% Print the results of the analysis:
% uq_print(PerturbationAnalysis)

% Display a graphical representation of the results:
% uq_display(PerturbationAnalysis)

%% 4.4 Cotter sensitivity indices
% Select the sensitivity tool and the Cotter method:
% CotterSensOpts.Type = 'Sensitivity';
% CotterSensOpts.Method = 'Cotter';

% % Specify the boundaries for the factorial design:
% CotterSensOpts.Factors.Boundaries = 0.5;

% Run the sensitivity analysis:
% CotterAnalysis = uq_createAnalysis(CotterSensOpts);

% Print the results of the analysis:
% uq_print(CotterAnalysis)

% Display a graphical representation of the results:
% uq_display(CotterAnalysis)

%% 4.5 Morris' elementary effects
% Select the sensitivity tool and the Morris method:
% MorrisSensOpts.Type = 'Sensitivity';
% MorrisSensOpts.Method = 'Morris';

% Specify the boundaries for the Morris method:
% MorrisSensOpts.Factors.Boundaries = 0.5;

% Make sure there are no unphysical values
% (e.g., with the positive-only lognormal variable #2).

% Specify the maximum cost (in terms of model evaluations) to calculate
% the Morris elementary effects:
% MorrisSensOpts.Morris.Cost = 300;

% Run the sensitivity analysis:
% MorrisAnalysis = uq_createAnalysis(MorrisSensOpts);

% Print the results of the analysis:
% uq_print(MorrisAnalysis)

% Display a graphical representation of the results:
% uq_display(MorrisAnalysis)

% Save Morris results:
% save result_morris.mat

%% 4.6 Sobol' indices
% Select the sensitivity tool and the Sobol' method:
SobolOpts.Type = 'Sensitivity';
SobolOpts.Method = 'Sobol';

% Specify the maximum order of the Sobol' indices calculation:
SobolOpts.Sobol.Order = 1;

% Specify the sample size for the indices estimation of each variable
SobolOpts.Sobol.SampleSize = 100;

% Note that the total cost of computation is $(M+2)\times N$,
% where $M$ is the input dimension and $N$ is the sample size.
% Therefore, the total cost for the current setup is
% $(26+2)\times 260 = 7280$ evaluations of the full computational model.

% Run the sensitivity analysis:
SobolAnalysis = uq_createAnalysis(SobolOpts);

% Print the results of the analysis:
uq_print(SobolAnalysis)

% Create a graphical representation of the results:
uq_display(SobolAnalysis)

% Save Sobol results:
save result_sobol_50.mat

%% 4.7 Borgonovo indices
% Select the sensitivity tool and the Borgonovo method:
% BorgonovoOpts.Type = 'Sensitivity';
% BorgonovoOpts.Method = 'Borgonovo';

% Specify the sample size:
% BorgonovoOpts.Borgonovo.SampleSize = 1e4;

% A relatively large sample size is recommended for Borgonovo indices 
% estimation, especially for complex functions.

% Specify the amount of classes in Xi direction:
% BorgonovoOpts.Borgonovo.NClasses = 20;

% By default, UQLab will then create classes that contain
% the same amount of sample points.

% Run the sensitivity analysis:
% BorgonovoAnalysis = uq_createAnalysis(BorgonovoOpts);

% Print the results of the analysis:
% uq_print(BorgonovoAnalysis)

% Create a graphical representation of the results:
% uq_display(BorgonovoAnalysis)

% In order to assess the accuracy of the results, it is possible to inspect 
% the 2D histogram estimation of the joint distribution used in the 
% calculation of an index:
% uq_display(BorgonovoAnalysis, 1, 'Joint PDF', 1)


