function results = uq_qmc(current_analysis)

Options = current_analysis.Internal ;

results = uq_runOptimization( current_analysis ) ;

end