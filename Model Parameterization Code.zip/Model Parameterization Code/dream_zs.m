function [x,y] = dream_zs(N,T,Npar,Nout,Obs,sd,range,Z0)
% DiffeRential Evolution Adaptive Metropolis with sampling from past archive
% and snooker update: DREAM_(ZS) algorithm
% Please study DREAM manual published in Environmental Modeling and Software, 2015:
%
% Code Written by Jasper A. Vrugt, Oct. 2015
% Full code of DREAM_ZS with all its options available from second author: jasper@uci.edu

[delta,c,c_star,n_CR,p_g] = deal(1,0.05,1e-12,3,0.2);                 % Default of algorithmic parameters
k = 10; p_s = 0.1; m0 = max(N,20 * Npar); n_d = 3*delta;              % DREAM_ZS algorithmic variables
x = nan(T,Npar,N); p_x = nan(T,N); y = nan(T,Nout,N);                 % Preallocate chains, density and model responses
[J,n_id] = deal(zeros(1,n_CR));                                       % Variables selection prob. crossover
CR = [1:n_CR]/n_CR; p_CR = ones(1,n_CR)/n_CR;                         % Crossover values and select. prob.
if nargin < 8
    xmin = range(:,1);
    xmax = range(:,2);
    Z = prior(m0,Npar,xmin,xmax);
else
    Z = Z0;
end
% Create initial archive
[Z(m0-N+1:m0,Npar+1),Y] = pdf(Z(m0-N+1:m0,1:Npar),Obs,sd);            % Compute log density and model responses of initial population
X = Z(m0-N+1:m0,1:Npar); p_X = Z(m0-N+1:m0,Npar+1); m = m0;           % Define X population and prepare Z
x(1,:,1:N) = reshape(X',1,Npar,N); p_x(1,1:N) = p_X';                 % Store initial states and density
y(1,:,1:N) = reshape(Y',1,Nout,N); id = nan(N,1);

for t = 2:T,    % Dynamic part: Evolution of N chains
    disp([num2str(t/T*100,'%4.2f'),'% finished'])                     % Show the process
    Xp = nan(N,Npar); dX = zeros(N,Npar); p_acc = nan(N,1);
    lambda = unifrnd(-c,c,N,1);                                       % Draw N lambda values
    std_X = std(X);                                                   % Compute std each dimension
    R = randsample(1:m,N*n_d,'false'); R = reshape(R,n_d,N);          % Sample N*n_d integer values from [1..m]
    method = randsample({'parallel' 'snooker'},1,'true',[1-p_s p_s]); % Mix of parallel and snooker updates
    for i = 1:N,                                                      % Create proposals and accept/reject
        D = randsample([1:delta],1,'true');                           % Select delta (equal select. prob.)
        a = R(1:D,i); b = R(D+1:2*D,i); c_sn = R(2*D+1:3*D,i);        % Define a and b (parallel) + c (snooker)
        if strcmp(method,'parallel'),                                 % PARALLEL DIRECTION update
            id(i) = randsample(1:n_CR,1,'true',p_CR);                 % Select index of crossover value
            z = rand(1,Npar);                                         % Draw d values from U[0,1]
            A = find(z < CR(id(i)));                                  % Derive subset A selected dimensions
            d_star = numel(A);                                        % How many dimensions sampled?
            if d_star == 0, [~,A] = min(z); d_star = 1; end           % A must contain at least one value
            gamma_d = 2.38/sqrt(2*D*d_star);                          % Calculate jump rate
            g = randsample([gamma_d 1],1,'true',[1-p_g p_g]);         % Select gamma: 80/20 mix [default 1]
            dX(i,A) = c_star*randn(1,d_star) + ...
                (1+lambda(i))*g*sum(Z(a,A)-Z(b,A),1);                 % Compute ith jump diff. evol.
        elseif strcmp(method,'snooker'),                              % SNOOKER update
            id(i) = n_CR;                                             % Full crossover
            F = X(i,1:Npar)-Z(a,1:Npar); D_e = max(F*F',1e-300);      % Define projection X(i,1:d) - Z(a,1:d)
            zP = F*( sum((Z(b,1:Npar)-Z(c_sn,1:Npar)).*F ) / D_e );   % Orthogonally project zR1 and zR2 onto F
            g = 1.2 + rand;                                           % Determine jump rate
            dX(i,1:Npar) = c_star*randn(1,Npar) + (1+lambda(i))*g*zP; % Calculate ith jump snooker update
        end
        Xp(i,1:Npar) = X(i,1:Npar) + dX(i,1:Npar);                    % Compute ith proposal
        Xp(i,:) = Boundary_handling(Xp(i,:),range,'reflect');         % Boundary handling
    end
    [p_Xp,Yp] = pdf(Xp,Obs,sd);                                       % Calculate the log pdf and the model responses
    
    % --------------------------------------------------------
    % If you want you can include here boundary treatment
    % --------------------------------------------------------
    if strcmp(method,'snooker'),                                      % Snooker correction: non-symmetry
        alfa_sn = (sum((Xp - Z(R(1,1:N),1:Npar)).^2,2)./sum((X - ...  % proposal distribution
            Z(R(1,1:N),1:Npar)).^2,2)).^((Npar-1)/2);
    elseif strcmp(method,'parallel'),                                 % otherwise no correction needed
        alfa_sn = ones(N,1);
    end
    for i = 1:N,                                                      % Accept/reject proposals (can use "parfor")
        p_acc(i) = min(1,alfa_sn(i)*exp(p_Xp(i,1)-p_X(i,1)));         % Compute acceptance probability                                                     % Accept/reject proposals
        if p_acc(i) > rand,                                           % p_acc(i) larger than U[0,1]?
            X(i,1:Npar) = Xp(i,1:Npar); p_X(i,1) = p_Xp(i,1);         % True: Accept proposal
            Y(i,:) = Yp(i,:);
        else
            dX(i,1:Npar) = 0;                                         % Set jump back to zero for p_CR
        end
        J(id(i)) = J(id(i)) + sum((dX(i,1:Npar)./std_X).^2);          % Update jump distance crossover idx
        n_id(id(i)) = n_id(id(i)) + 1;                                % How many times idx crossover used
    end
    x(t,1:Npar,1:N) = reshape(X',1,Npar,N); p_x(t,1:N) = p_X';        % Append current X and density
    y(t,1:Nout,1:N) = reshape(Y',1,Nout,N);                           % Append model responses;
    if (mod(t,k) == 0),                                               % Check whether to append X to archive Z
        Z(m+1:m+N,1:Npar+1) = [X p_X]; m = m + N;                     % Append current values to Z after k generations
        if t<T/10, p_CR = J./n_id; p_CR = p_CR/sum(p_CR); end         % Update selection prob. crossover
    end
    % --------------------------------------------------------
    % If you want you can compute here convergence diagnostics
    % --------------------------------------------------------
end             % End dynamic part

end

function [x] = Boundary_handling(x,range,flag)
% Function to check whether parameter values remain within prior bounds

% First determine the size of x
[m,~] = size(x);
% Now replicate min and max
min_d = repmat(range(:,1)',m,1); max_d = repmat(range(:,2)',m,1);
% Now find which elements of x are smaller than their respective bound
[ii_low] = find(x < min_d);
% Now find which elements of x are larger than their respective bound
[ii_up] = find(x > max_d);

switch flag
    case 'reflect'  % reflection
        % reflect in min
        x(ii_low)= 2 * min_d(ii_low) - x(ii_low);
        % reflect in max
        x(ii_up)= 2 * max_d(ii_up) - x(ii_up);
    case 'bound'    % set to bound
        % set lower values to min
        x(ii_low)= min_d(ii_low);
        % set upper values to max
        x(ii_up)= max_d(ii_up);
    case 'fold'     % folding
        % Fold parameter space lower values
        x(ii_low) = max_d(ii_low) - ( min_d(ii_low) - x(ii_low) );
        % Fold parameter space upper values
        x(ii_up) = min_d(ii_up) + ( x(ii_up) - max_d(ii_up) );
        % Now double check in case elements are still out of bound -- this is
        % theoretically possible if values are very small or large
    otherwise
        disp('do not know this boundary handling option! - treat as unbounded parameter space')
end

% Now double check if all elements are within bounds
% If parameter so far out of space then possible that reflection or
% folding still creates point that is out of bound - this is very
% rare but needs explicit consideration
if strcmp(flag,'reflect') || strcmp(flag,'fold')
    % Lower bound
    [ii_low] = find(x < min_d); x(ii_low) = min_d(ii_low) + rand(size(ii_low)).* ( max_d(ii_low) - min_d(ii_low) );
    % Upper bound
    [ii_up]  = find(x > max_d); x(ii_up)  = min_d(ii_up)  + rand(size(ii_up)).*  ( max_d(ii_up)  - min_d(ii_up)  );
end
end