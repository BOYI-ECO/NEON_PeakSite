#!/usr/bin/env python
# coding: utf-8

# # Main Function: Simulation Lab incubation

# In[1]:


##Sample site & Lab incubation days##
site = 2
day	 = 600

#Package import#
import numpy as np
import pandas as pd
from Decomposition_MM import CWD_pool
from Decomposition_MM import SOM_pool
from Decomposition_MM import av_Nitro
from Decomposition_MM import CWDFrag_OrgInAllocLab		       ###QQQ:20210602
from Decomposition_MM import SoilDecom_pot
from Decomposition_MM import SoilDecom_real
from Decomposition_MM import initial_content
from Decomposition_MM import lls_CO2

## Date for Lab measurement ##
day_selected = np.int32(np.loadtxt('day_obser.txt'))
day_selected = day_selected
# Read (Optimization) parameters getting from Matlab #
decom_para_1 = np.loadtxt('para.txt')					   # Paras need to be optimized #
decom_para = pd.read_csv("decom_para.csv",index_col=0)	   # Paras #

#Looping for Each Site#
for sample_site in range(1,site):
	#Input data#
	obser_data = pd.read_csv("obser_data.csv",index_col=0)
	#Parameters-MCMC#
	#Parameters#
	CN_AOM1	   = decom_para_1[0]
	CN_AOM2	   = decom_para_1[1]
	CN_AOM3	   = decom_para_1[2]
	CN_SMB1	   = decom_para_1[3]
	CN_SMB2	   = decom_para_1[4]
	CN_SMR	   = decom_para_1[5]
	CN_NOM	   = decom_para_1[6]
	CN_MOM	   = decom_para_1[7]
	k1max_AOM1 = decom_para_1[8]
	k2max_AOM1 = decom_para_1[9]
	k1max_AOM2 = decom_para_1[10]
	k2max_AOM2 = decom_para_1[11]
	k1max_AOM3 = decom_para_1[12]
	k2max_AOM3 = decom_para_1[13]
	k1max_NOM  = decom_para_1[14]
	k2max_NOM  = decom_para_1[15]
	kmax_NOM   = decom_para_1[16]
	kmax_SMR   = decom_para_1[17]
	kmax_MOM   = decom_para_1[18]
	CUE1_AOM1  = decom_para_1[19]
	CUE1_AOM2  = decom_para_1[20]
	CUE1_AOM3  = decom_para_1[21]
	CUE1_NOM   = decom_para_1[22]
	CUE2_AOM1  = decom_para_1[23]
	CUE2_AOM2  = decom_para_1[24]
	CUE2_AOM3  = decom_para_1[25]
	CUE2_NOM   = decom_para_1[26]
	KM1_AOM1   = decom_para_1[27]
	KM1_AOM2   = decom_para_1[28]
	KM1_AOM3   = decom_para_1[29]
	KM1_NOM    = decom_para_1[30]
	KM2_AOM1   = decom_para_1[31]
	KM2_AOM2   = decom_para_1[32]
	KM2_AOM3   = decom_para_1[33]
	KM2_NOM    = decom_para_1[34]
	death1_rate1 = decom_para_1[35]
	death2_rate1 = decom_para_1[36]
	death2_rate2 = decom_para_1[37]
	lig_p1	   = decom_para_1[38]
	lig_p2	   = decom_para_1[39]
	#Class initialization#
	litter = CWD_pool(obser_data,sample_site,"litter")
	AOM1   = SOM_pool(obser_data,sample_site,'AOM1')
	AOM2   = SOM_pool(obser_data,sample_site,'AOM2')
	AOM3   = SOM_pool(obser_data,sample_site,'AOM3')
	SMB1   = SOM_pool(obser_data,sample_site,'SMB1')
	SMB2   = SOM_pool(obser_data,sample_site,'SMB2')
	SMR	   = SOM_pool(obser_data,sample_site,'SMR')
	NOM	   = SOM_pool(obser_data,sample_site,'NOM')
	MOM	   = SOM_pool(obser_data,sample_site,'MOM')
	avN	   = av_Nitro(obser_data,sample_site)
	initCont   = initial_content()
	initCont.MicroSMB1Zero(SMB1.C)
	initCont.MicroSMB2Zero(SMB2.C)
	#initCont.LitterSub(litter.C*kbase_litter)
	#initCont.SoilSub(NOM.C*kmax_NOM)
	#Data Collection#
	Rh=[]
	flag_SMB1 = 0
	flag_SMB2 = 0
	
	CWDFrag_OrgInAllocLab(sample_site,obser_data,litter,AOM1,AOM2,AOM3,CN_AOM1,CN_AOM2,CN_AOM3)	               ###QQQ:20210602
	#Looping for Each Inbubation Day#
	for t in range(1,day):
		potimm = 0
		Nmin = 0
		litligsoil_CO2 = lls_CO2()


		bimm_AOM1,bimm_AOM2,bimm_AOM3,bimm_SMR,bimm_NOM,bimm_MOM,potimm = SoilDecom_pot(sample_site,t,obser_data,potimm,flag_SMB1,flag_SMB2,lig_p1,lig_p2,             #Scalar(6)#   ###QQQ: 20210908: lignin decay log para #
                  																		 AOM1,AOM2,AOM3,SMB1,SMB2,SMR,NOM,MOM,initCont,                   #Class(9)#
                  																		 CN_SMB1,CN_SMB2,CN_SMR,CN_NOM,CN_MOM,                            #CN Ratio(5)#
                  																		 k1max_AOM1,k1max_AOM2,k1max_AOM3,k1max_NOM,k2max_AOM1,k2max_AOM2,k2max_AOM3,k2max_NOM,kmax_SMR,kmax_NOM,kmax_MOM,        #Decay Rate(6)#
                  																		 CUE1_AOM1,CUE1_AOM2,CUE1_AOM3,CUE1_NOM,CUE2_AOM1,CUE2_AOM2,CUE2_AOM3,CUE2_NOM,    #Fraction(6)#
                  																		 KM1_AOM1,KM1_AOM2,KM1_AOM3,KM1_NOM,KM2_AOM1,KM2_AOM2,KM2_AOM3,KM2_NOM,death1_rate1,death2_rate1,death2_rate2)

		Rh,flag_SMB1,flag_SMB2 = SoilDecom_real (sample_site,t,obser_data,Nmin,potimm,flag_SMB1,flag_SMB2,Rh,lig_p1,lig_p2,     #Scalar(7)#  ###QQQ: 20210908: add 2 logistic lignin para to control lignin decomposition ###
												 AOM1,AOM2,AOM3,SMB1,SMB2,SMR,NOM,MOM,avN,initCont,litligsoil_CO2,              #Class(10)#
                    							 bimm_AOM1,bimm_AOM2,bimm_AOM3,bimm_SMR,bimm_NOM,bimm_MOM,                      #N scalar(6)#
                                                 CN_SMB1,CN_SMB2,CN_SMR,CN_NOM,CN_MOM,                                          #CN Ratio#
                                                 k1max_AOM1,k1max_AOM2,k1max_AOM3,kmax_SMR,k1max_NOM,kmax_NOM,kmax_MOM,k2max_AOM1,k2max_AOM2,k2max_AOM3,k2max_NOM,        #Decay Rate(6)#
                    							 CUE1_AOM1,CUE1_AOM2,CUE1_AOM3,CUE1_NOM,CUE2_AOM1,CUE2_AOM2,CUE2_AOM3,CUE2_NOM,
                    							 KM1_AOM1,KM1_AOM2,KM1_AOM3,KM1_NOM,KM2_AOM1,KM2_AOM2,KM2_AOM3,KM2_NOM,death1_rate1,death2_rate1,death2_rate2)


	##Data Output##
	Rh_array = np.array(Rh)
	Rh_Day = Rh_array.reshape(-1,12)
	Rh_Day_selected = Rh_Day[day_selected,:]
	Rh_Day_selected_frame = pd.DataFrame(Rh_Day_selected[:,-3:])
	Rh_Day_selected_frame_lss = pd.melt(Rh_Day_selected_frame).iloc[:,-1]
	np.savetxt('Rh_sum.txt',Rh_Day_selected_frame_lss)


